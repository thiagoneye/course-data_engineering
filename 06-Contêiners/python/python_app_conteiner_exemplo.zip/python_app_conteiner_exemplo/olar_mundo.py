def main():
    for i in ['bom dia','boa tarde','boa noite', 'por enquanto']:
        print('Gilbrother says : '+i)



if __name__=='__main__':
    main()